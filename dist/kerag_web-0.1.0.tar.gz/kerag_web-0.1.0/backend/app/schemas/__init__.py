"""Schema definitions for the web API."""

from .responses import *
