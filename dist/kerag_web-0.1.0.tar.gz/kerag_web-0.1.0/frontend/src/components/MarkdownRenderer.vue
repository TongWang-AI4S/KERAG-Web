<template>
  <div class="markdown-content" v-html="renderedContent"></div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  content: string;
}>();

const renderedContent = computed(() => {
  // 简单的Markdown转换（可以根据需要增强）
  let html = props.content
    // 标题
    .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold mt-4 mb-2">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mt-4 mb-2">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mt-4 mb-3">$1</h1>')
    // 粗体
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // 斜体
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // 代码块
    .replace(/```([\s\S]*?)```/g, '<pre class="bg-gray-100 p-3 rounded my-2 overflow-x-auto"><code>$1</code></pre>')
    // 行内代码
    .replace(/`(.+?)`/g, '<code class="bg-gray-100 px-1 rounded text-sm">$1</code>')
    // 链接
    .replace(/\[([^\]]+)\]\(([^\)]+)\)/g, '<a href="$2" class="text-blue-600 hover:text-blue-800 underline">$1</a>')
    // 列表
    .replace(/^\* (.+)/gim, '<li class="ml-4">$1</li>')
    .replace(/^- (.+)/gim, '<li class="ml-4">$1</li>')
    .replace(/^\d+\. (.+)/gim, '<li class="ml-4">$1</li>')
    // 段落
    .replace(/\n\n/g, '</p><p class="mb-3">')
    .replace(/^(.+)$/gim, '<p class="mb-3">$1</p>');

  return html;
});
</script>

<style scoped>
.markdown-content {
  @apply text-gray-800;
}</style>
