# KERAG Web - Knowledge Base Explorer

A modern web interface for the KERAG knowledge base, built with Vue 3, TypeScript, and Pinia.

## 🚀 Installation

Clone the repository and install dependencies:

```bash
git clone https://github.com/____/kerag-web.git
cd kerag-web
```

*(Note: Replace the URL above with the actual repository link.)*

## 🛠 Quick Start

The easiest way to start both the backend and frontend is using the launch script:

```bash
python launch.py
```

This will automatically:
1. Start the FastAPI backend.
2. Install frontend dependencies (if needed).
3. Build and serve the frontend.
4. Open your browser to the application.

## ✨ Features

- **Module Management**: Load and unload knowledge modules easily.
- **Tree Navigation**: Intuitive hierarchical browsing with breadcrumbs.
- **Rich Content Display**: View notes in Markdown, Plain Text, Tree, or JSON formats.
- **Full-text Search**: Find information quickly across your entire knowledge base.

## 📄 License

This project is licensed under the MIT License.
